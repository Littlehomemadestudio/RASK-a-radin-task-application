// Top-level settings file — configures plugin & dependency resolution for all modules.
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://jitpack.io") } // for MPAndroidChart & alternatives
    }
}

rootProject.name = "Rask"
include(":app")
